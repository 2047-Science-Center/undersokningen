#pragma once
// Undersökningen — PN532-scanner (station 3). Erik-kit.
// WiFi-lösenordet lämnas TOMT och fylls i på plats (committas aldrig).

// --- WiFi ---
#define WIFI_SSID  "2047p"
#define WIFI_PASS  ""              // FYLL I på plats (2047p:s lösenord)

// --- MQTT: 2047-brokern (extern, finns redan — ingen egen broker) ---
#define MQTT_HOST  "192.168.0.23"  // 2047-brokern (MQTT), TCP 1883
#define MQTT_PORT  1883

// --- Station ---
#define STATION_N  3               // → station3/scan, station3/status

// --- I2C-pinnar (Waveshare ESP32-S3-ETH). Fyra pinnar i rad: 3V3/21/17/GND ---
#define PN532_SDA  21              // header-pin 35
#define PN532_SCL  17              // header-pin 34

#define COOLDOWN_MS 1500           // samma tagg inom X ms skickas inte om (debounce)
